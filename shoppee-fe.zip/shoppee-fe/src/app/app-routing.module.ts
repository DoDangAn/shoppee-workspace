import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Home } from './modules/home/pages/home/home'; // đường dẫn tới component Home

const routes: Routes = [
  { path: '', component: Home },   // 👈 route mặc định khi mở trang
  { path: 'home', component: Home } // có thể thêm nếu muốn /home
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule {}

